//
//  AnimalApp.swift
//  Animal
//
//  Created by Turma02-8 on 22/04/25.
//

import SwiftUI

@main
struct AnimalApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
